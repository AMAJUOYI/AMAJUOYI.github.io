
import React from 'react'
import ReactDOM from 'react-dom/client'
import RedFitApp from './RedFitApp.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RedFitApp />
  </React.StrictMode>
)
