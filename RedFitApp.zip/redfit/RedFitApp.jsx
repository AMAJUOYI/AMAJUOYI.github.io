import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function RedFitApp() {
  const [tab, setTab] = useState("home");

  const workoutPlan = ["Jumping Jacks - 30 sec", "Push-ups - 10 reps", "Squats - 15 reps", "Plank - 30 sec"];
  const motivation = "Consistency is what transforms average into excellence.";
  const quickTips = ["Warm up before starting!", "Stay hydrated.", "Breathe properly during exercises."];

  return (
    <div className="min-h-screen bg-red-100 p-4 text-red-900">
      <h1 className="text-3xl font-bold text-center mb-4">RedFit</h1>

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="flex justify-center mb-4">
          <TabsTrigger value="home">Home</TabsTrigger>
          <TabsTrigger value="guide">Guide</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>

        {tab === "home" && (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold mb-2">Today's Workout</h2>
                <ul className="list-disc list-inside">
                  {workoutPlan.map((exercise, index) => (
                    <li key={index}>{exercise}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold mb-2">Motivation</h2>
                <p>{motivation}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {tab === "guide" && (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold mb-2">Quick Start Tips</h2>
                <ul className="list-disc list-inside">
                  {quickTips.map((tip, index) => (
                    <li key={index}>{tip}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}

        {tab === "progress" && (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <h2 className="text-xl font-semibold mb-2">Progress Log</h2>
                <p>Coming soon: track your workouts and achievements!</p>
              </CardContent>
            </Card>
          </div>
        )}
      </Tabs>
    </div>
  );
}
